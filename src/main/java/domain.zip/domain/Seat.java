package domain;

/**
 * Created by Administrator on 2016/9/20.
 */
public class Seat {
}
